import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand } from '@aws-sdk/lib-dynamodb';

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

// CORSヘッダー
const corsHeaders = {
    'Access-Control-Allow-Origin': 'http://localhost:3000',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,OPTIONS,POST',
    'Access-Control-Allow-Credentials': 'true',
    'Content-Type': 'application/json'
};

export const handler = async (event) => {
    console.log('Event:', event);
    
    try {
        // Cognitoユーザー情報からuserIdを取得
        const userId = event.requestContext.authorizer.claims.sub;
        console.log('UserId:', userId);
        
        // DynamoDBから取引履歴を取得
        const params = {
            TableName: 'DigiCoin-Transactions',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': userId
            },
            ScanIndexForward: false, // 新しい順
            Limit: 20 // 最新20件を取得
        };
        
        console.log('Query params:', params);
        
        const command = new QueryCommand(params);
        const result = await dynamodb.send(command);
        
        console.log('DynamoDB Result:', result);
        
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify(result.Items || [])
        };
        
    } catch (error) {
        console.error('Error:', {
            message: error.message,
            stack: error.stack,
            error
        });
        
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ 
                message: 'Internal server error',
                error: error.message 
            })
        };
    }
}; 