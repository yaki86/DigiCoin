import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
import { ethers } from 'ethers';

const dynamodb = DynamoDBDocument.from(new DynamoDB());
const secretsManagerClient = new SecretsManagerClient();
const ssmClient = new SSMClient();

async function getSecret(secretName) {
    const command = new GetSecretValueCommand({ SecretId: secretName });
    const response = await secretsManagerClient.send(command);
    return response.SecretString;
}

async function getParameter(parameterName) {
    const command = new GetParameterCommand({ Name: parameterName });
    const response = await ssmClient.send(command);
    return response.Parameter.Value;
}

export const handler = async (event) => {
    const { senderId, recipientId, amount } = JSON.parse(event.body);

    try {
        // Secrets Managerから秘密鍵とABIを個別に取得
        const privateKeySecretName = 'PRIVATE_KEY'; // 秘密鍵のシークレット名
        const abiSecretName = 'DIGICOIN_ABI'; // ABIのシークレット名

        const privateKey = await getSecret(privateKeySecretName); // シークレットから秘密鍵を取得
        const DigiCoinABI = JSON.parse(await getSecret(abiSecretName)); // シークレットからABIを取得

        // Parameter StoreからETHEREUM_RPC_URLとDIGICOIN_CONTRACT_ADDRESSを取得
        const ethereumRpcUrl = await getParameter('/path/to/ETHEREUM_RPC_URL');
        const digiCoinContractAddress = await getParameter('/path/to/DIGICOIN_CONTRACT_ADDRESS');

        const provider = new ethers.JsonRpcProvider(ethereumRpcUrl);
        const wallet = new ethers.Wallet(privateKey, provider);

        const digiCoinContract = new ethers.Contract(digiCoinContractAddress, DigiCoinABI, wallet);

        // 送付元と送付先のユーザー情報を取得
        const senderParams = {
            TableName: 'DigiCoin-Users',
            Key: { userId: senderId }
        };
        const recipientParams = {
            TableName: 'DigiCoin-Users',
            Key: { userId: recipientId }
        };

        const senderResult = await dynamodb.get(senderParams);
        const recipientResult = await dynamodb.get(recipientParams);

        const sender = senderResult.Item;
        const recipient = recipientResult.Item;

        if (!sender || !recipient) {
            throw new Error('送信者または受信者が見つかりません');
        }

        if (sender.balance < amount) {
            throw new Error('送付可能な残高が不足しています');
        }

        // 残高の更新
        sender.balance -= amount;
        recipient.balance += amount;
        sender.total += 1;

        // DynamoDBに更新を保存
        await dynamodb.put({
            TableName: 'DigiCoin-Users',
            Item: sender
        });
        await dynamodb.put({
            TableName: 'DigiCoin-Users',
            Item: recipient
        });

        // スマートコントラクトに送金履歴を記録
        const tx = await digiCoinContract.recordTransfer(senderId, recipientId, amount);
        const receipt = await tx.wait();

        // 取引をDynamoDBに保存
        const transactionParams = {
            TableName: 'DigiCoin-Transactions',
            Item: {
                transactionId: receipt.transactionHash,
                senderId,
                recipientId,
                amount,
                timestamp: new Date().toISOString()
            }
        };
        await dynamodb.put(transactionParams);

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: '送付が完了しました',
                transactionHash: receipt.transactionHash,
                newSenderBalance: sender.balance
            })
        };
    } catch (error) {
        console.error('送付エラー:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: '送付に失敗しました', error: error.message })
        };
    }
};
