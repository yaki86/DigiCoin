import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamodb = DynamoDBDocument.from(new DynamoDB());

export const handler = async (event) => {
    try {
        // Cognitoユーザー情報から userId を取得
        const userId = event.requestContext.authorizer.claims.sub;
        
        // DynamoDBからユーザー情報を取得
        const params = {
            TableName: 'DigiCoin-Users',
            Key: {
                userId: userId
            }
        };
        
        const result = await dynamodb.get(params);
        const user = result.Item;
        
        if (!user) {
            return {
                statusCode: 404,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Methods": "GET"
                },
                body: JSON.stringify({ message: 'ユーザーが見つかりません' })
            };
        }
        
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "GET"
            },
            body: JSON.stringify({
                currentBalance: user.currentBalance || 0,
                totalSentAmount: user.totalSentAmount || 0
            })
        };
        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "GET"
            },
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
}; 